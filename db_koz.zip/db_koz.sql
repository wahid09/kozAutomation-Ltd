-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 28, 2017 at 03:21 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_koz`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `admin_id` int(3) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `email_address` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`admin_id`, `admin_name`, `email_address`, `password`) VALUES
(4, 'Nejum Islam', 'nejum.islam@gmail.com', '4297f44b13955235245b2497399d7a93'),
(12, 'KOZ Automation BD. Ltd.', 'admin@koz.com', '25d55ad283aa400af464c76d713c07ad');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_aesthetical`
--

CREATE TABLE `tbl_aesthetical` (
  `project_id` int(11) NOT NULL,
  `project_name` varchar(100) NOT NULL,
  `project_type` tinyint(2) NOT NULL,
  `project_location` varchar(100) NOT NULL,
  `project_description` text NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `image_one` text NOT NULL,
  `image_two` text NOT NULL,
  `image_three` text NOT NULL,
  `image_four` text NOT NULL,
  `image_five` text NOT NULL,
  `video_link` text NOT NULL,
  `publication_status` tinyint(1) NOT NULL,
  `deletion_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_aesthetical`
--

INSERT INTO `tbl_aesthetical` (`project_id`, `project_name`, `project_type`, `project_location`, `project_description`, `contact_person`, `image_one`, `image_two`, `image_three`, `image_four`, `image_five`, `video_link`, `publication_status`, `deletion_status`) VALUES
(1, 'Sagor Samart It zone', 3, 'Savar Dhaka', 'aaaaaaaaa', 'Md. Reza 01678702', '../assets/images/project_images/p7-3.jpg', '../assets/images/project_images/p5-5.jpg', '../assets/images/project_images/p5-6.jpg', '../assets/images/project_images/p6-1.jpg', '../assets/images/project_images/p5-4.jpg', 'https://www.youtube.com/watch?v=lpdRqn6xwiM', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact`
--

CREATE TABLE `tbl_contact` (
  `contact_id` int(11) NOT NULL,
  `contact_name` varchar(100) NOT NULL,
  `contact_email` varchar(100) NOT NULL,
  `contact_message` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `reply_status` tinyint(1) NOT NULL,
  `deletion_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_contact`
--

INSERT INTO `tbl_contact` (`contact_id`, `contact_name`, `contact_email`, `contact_message`, `status`, `reply_status`, `deletion_status`) VALUES
(4, 'younus', 'younus@gmail.com', 'Message messageMessage messageMessage messageMessage messageMessage message', 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_dhaka`
--

CREATE TABLE `tbl_dhaka` (
  `project_id` int(11) NOT NULL,
  `project_name` varchar(100) NOT NULL,
  `project_type` tinyint(2) NOT NULL,
  `project_location` varchar(100) NOT NULL,
  `project_description` text NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `image_one` text NOT NULL,
  `image_two` text NOT NULL,
  `image_three` text NOT NULL,
  `image_four` text NOT NULL,
  `image_five` text NOT NULL,
  `video_link` text NOT NULL,
  `publication_status` tinyint(1) NOT NULL,
  `deletion_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_dhaka`
--

INSERT INTO `tbl_dhaka` (`project_id`, `project_name`, `project_type`, `project_location`, `project_description`, `contact_person`, `image_one`, `image_two`, `image_three`, `image_four`, `image_five`, `video_link`, `publication_status`, `deletion_status`) VALUES
(1, 'Sagor It zone', 1, 'Zirabo, Ashulia, Savar, Dhaka.', 'aaaaaaaaaa', 'Md. Reza 01678702', '../assets/images/project_images/p1-1.jpg', '../assets/images/project_images/p1-2.jpg', '../assets/images/project_images/p1-3.jpg', '../assets/images/project_images/p1-4.jpg', '../assets/images/project_images/p2-1.jpg', 'https://www.youtube.com/watch?v=lpdRqn6xwiM', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_project`
--

CREATE TABLE `tbl_project` (
  `project_id` int(11) NOT NULL,
  `project_name` varchar(100) NOT NULL,
  `project_type` tinyint(2) NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `project_location` varchar(100) NOT NULL,
  `project_description` text NOT NULL,
  `project_area` varchar(100) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `contact_number` varchar(100) NOT NULL,
  `image_one` text NOT NULL,
  `image_two` text NOT NULL,
  `image_three` text NOT NULL,
  `image_four` text NOT NULL,
  `image_five` text NOT NULL,
  `video_link` text NOT NULL,
  `publication_status` tinyint(1) NOT NULL,
  `deletion_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_project`
--

INSERT INTO `tbl_project` (`project_id`, `project_name`, `project_type`, `company_name`, `project_location`, `project_description`, `project_area`, `contact_person`, `contact_number`, `image_one`, `image_two`, `image_three`, `image_four`, `image_five`, `video_link`, `publication_status`, `deletion_status`) VALUES
(7, 'Zaalima Zaalima ', 3, '', ' Mahira Khan', 'Red Chillies Entertainment and Excel Entertainment Present Present', '', 'Shah Rukh Khan - 01678 Present', '', '../assets/images/project_images/p3-1.jpg', '../assets/images/project_images/p1-2.jpg', '../assets/images/project_images/p1-3.jpg', '../assets/images/project_images/p1-4.jpg', '../assets/images/project_images/p2-1.jpg', 'https://www.youtube.com/watch?v=lpdRqn6xwiM', 1, 0),
(8, 'Samart It zone', 1, '', '', '', '', '', '', '../assets/images/project_images/DSC00433_1.JPG', '../assets/images/project_images/', '../assets/images/project_images/', '../assets/images/project_images/', '../assets/images/project_images/', '', 1, 1),
(9, 'Yarn Godown._1', 3, '', '', '', '', '', '', '../assets/images/project_images/DSC00433.JPG', '../assets/images/project_images/DSC00434.JPG', '../assets/images/project_images/DSC00435.JPG', '../assets/images/project_images/DSC00437.JPG', '../assets/images/project_images/DSC00433.JPG', '', 1, 1),
(10, 'hjhj', 2, '', '', '', '', '', '', '../assets/images/project_images/DSC00433.JPG', '../assets/images/project_images/DSC00434.JPG', '../assets/images/project_images/DSC00435.JPG', '../assets/images/project_images/DSC00437.JPG', '../assets/images/project_images/DSC00437.JPG', '', 0, 1),
(11, 'Samart It zone', 2, '', 'Zirabo, Ashulia, Savar, Dhaka.', 'hhhhhhhhhhhh', '', 'hhhh-121212', '', '../assets/images/project_images/p3-2.jpg', '../assets/images/project_images/p3-3.jpg', '../assets/images/project_images/p4-1.jpg', '../assets/images/project_images/p4-1.jpg', '../assets/images/project_images/p4-2.jpg', 'https://www.youtube.com/watch?v=lpdRqn6xwiM', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_skilltech`
--

CREATE TABLE `tbl_skilltech` (
  `project_id` int(11) NOT NULL,
  `project_name` varchar(100) NOT NULL,
  `project_type` tinyint(2) NOT NULL,
  `project_location` varchar(100) NOT NULL,
  `project_description` text NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `image_one` text NOT NULL,
  `image_two` text NOT NULL,
  `image_three` text NOT NULL,
  `image_four` text NOT NULL,
  `image_five` text NOT NULL,
  `video_link` text NOT NULL,
  `publication_status` tinyint(1) NOT NULL,
  `deletion_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_skilltech`
--

INSERT INTO `tbl_skilltech` (`project_id`, `project_name`, `project_type`, `project_location`, `project_description`, `contact_person`, `image_one`, `image_two`, `image_three`, `image_four`, `image_five`, `video_link`, `publication_status`, `deletion_status`) VALUES
(1, 'Sagor It zone area', 3, 'Zirabo, Ashulia, Savar,', 'dfdfdfdfdd', 'Md. Reza 01678702', '../assets/images/project_images/p23-9.jpg', '../assets/images/project_images/p1-2.jpg', '../assets/images/project_images/p4-2.jpg', '../assets/images/project_images/p4-1.jpg', '../assets/images/project_images/p3-1.jpg', 'https://www.youtube.com/watch?v=lpdRqn6xwiM', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_smart`
--

CREATE TABLE `tbl_smart` (
  `project_id` int(11) NOT NULL,
  `project_name` varchar(100) NOT NULL,
  `project_type` tinyint(2) NOT NULL,
  `project_location` varchar(100) NOT NULL,
  `project_description` text NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `image_one` text NOT NULL,
  `image_two` text NOT NULL,
  `image_three` text NOT NULL,
  `image_four` text NOT NULL,
  `image_five` text NOT NULL,
  `video_link` text NOT NULL,
  `publication_status` tinyint(1) NOT NULL,
  `deletion_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_smart`
--

INSERT INTO `tbl_smart` (`project_id`, `project_name`, `project_type`, `project_location`, `project_description`, `contact_person`, `image_one`, `image_two`, `image_three`, `image_four`, `image_five`, `video_link`, `publication_status`, `deletion_status`) VALUES
(1, 'Yarn Godown.Godown.', 2, 'Zirabo, Ashulia, Savar, Dhaka.', 'qqqqqqqqqqq', 'Md. Reza 01678702', '../assets/images/project_images/p4-1.jpg', '../assets/images/project_images/p3-1.jpg', '../assets/images/project_images/p4-2.jpg', '../assets/images/project_images/p3-3.jpg', '../assets/images/project_images/p2-3.jpg', 'https://www.youtube.com/watch?v=lpdRqn6xwiM', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_super`
--

CREATE TABLE `tbl_super` (
  `project_id` int(11) NOT NULL,
  `project_name` varchar(100) NOT NULL,
  `project_type` tinyint(2) NOT NULL,
  `project_location` varchar(100) NOT NULL,
  `project_description` text NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `image_one` text NOT NULL,
  `image_two` text NOT NULL,
  `image_three` text NOT NULL,
  `image_four` text NOT NULL,
  `image_five` text NOT NULL,
  `video_link` text NOT NULL,
  `publication_status` tinyint(1) NOT NULL,
  `deletion_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_super`
--

INSERT INTO `tbl_super` (`project_id`, `project_name`, `project_type`, `project_location`, `project_description`, `contact_person`, `image_one`, `image_two`, `image_three`, `image_four`, `image_five`, `video_link`, `publication_status`, `deletion_status`) VALUES
(1, 'Sagor It', 1, 'Savar Dhaka', 'ddddd', 'Md. Reza 01678702', '../assets/images/project_images/p1-1.jpg', '../assets/images/project_images/p1-2.jpg', '../assets/images/project_images/p1-3.jpg', '../assets/images/project_images/p3-3.jpg', '../assets/images/project_images/p1-4.jpg', 'https://www.youtube.com/watch?v=lpdRqn6xwiM', 1, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tbl_aesthetical`
--
ALTER TABLE `tbl_aesthetical`
  ADD PRIMARY KEY (`project_id`);

--
-- Indexes for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  ADD PRIMARY KEY (`contact_id`);

--
-- Indexes for table `tbl_dhaka`
--
ALTER TABLE `tbl_dhaka`
  ADD PRIMARY KEY (`project_id`);

--
-- Indexes for table `tbl_project`
--
ALTER TABLE `tbl_project`
  ADD PRIMARY KEY (`project_id`);

--
-- Indexes for table `tbl_skilltech`
--
ALTER TABLE `tbl_skilltech`
  ADD PRIMARY KEY (`project_id`);

--
-- Indexes for table `tbl_smart`
--
ALTER TABLE `tbl_smart`
  ADD PRIMARY KEY (`project_id`);

--
-- Indexes for table `tbl_super`
--
ALTER TABLE `tbl_super`
  ADD PRIMARY KEY (`project_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `admin_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `tbl_aesthetical`
--
ALTER TABLE `tbl_aesthetical`
  MODIFY `project_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  MODIFY `contact_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tbl_dhaka`
--
ALTER TABLE `tbl_dhaka`
  MODIFY `project_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_project`
--
ALTER TABLE `tbl_project`
  MODIFY `project_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `tbl_skilltech`
--
ALTER TABLE `tbl_skilltech`
  MODIFY `project_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_smart`
--
ALTER TABLE `tbl_smart`
  MODIFY `project_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_super`
--
ALTER TABLE `tbl_super`
  MODIFY `project_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
